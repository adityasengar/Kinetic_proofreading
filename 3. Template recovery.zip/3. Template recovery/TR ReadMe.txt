TR = Template recovery

BT + P --> BP + T
BP + RQ --> BPR + Q

side reaction

P + RQ --> PR + Q

Subtract Control3 from all columns.


Alexafluor647 signals = RQ + BPR + PR
use CC5 and CC6. Treat BPR and PR signal intensity/nM as same, CC6.

Cy3 signals = BT + BP+ BPR
CC2, 3, 4

For actual concentration of initially added BT, take the mean/median (which one would be better suited?) of last 40-50 datapints
of Cy3 channel, and treat them with CC4.

For Actual concentrations of initially added RQ, use respective 'sat red' files and take the mean/median of the data and treat them with CC6