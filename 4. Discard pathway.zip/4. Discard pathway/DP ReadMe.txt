DP = Discard pathway

BL + T --> BT + L
BT + P --> BP + T
BP + RQ --> BPR + Q

side reaction

P + RQ --> PR + Q
BL + P --> BP + L

Subtract Control3 from all columns.


Alexafluor647 signals = RQ + BPR + PR
use CC5 and CC6. Treat BPR and PR signal intensity/nM as same, CC6.


Cy3 signals = BL + BT + BP + BPR
CC1,2, 3, 4

For actual concentration of initially added BL, take the mean/median (which one would be better suited?) of last 10 datapoints
of Cy3 channel, and treat them with CC4.

For Actual concentrations of initially added RQ, use respective 'sat red' files and take the mean/median of the data and treat them with CC6

